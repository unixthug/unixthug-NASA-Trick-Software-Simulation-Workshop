from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
import sys
import os
sys.path.append(os.getcwd() + "/trick.zip/trick")

import _sim_services
from sim_services import *

# create "all_cvars" to hold all global/static vars
all_cvars = new_cvar_list()
combine_cvars(all_cvars, cvar)
cvar = None

# /home/caci114/trick_sims/SIM_submarine/S_source.hh
import _maf042a8ac26a39366393033f022b7bed
combine_cvars(all_cvars, cvar)
cvar = None

# /home/caci114/trick_sims/SIM_submarine/models/submarine/include/Submarine.hh
import _mf25fb9851ae0aec07f6f6b611d204e49
combine_cvars(all_cvars, cvar)
cvar = None

# /home/caci114/trick_sims/SIM_submarine/S_source.hh
from maf042a8ac26a39366393033f022b7bed import *
# /home/caci114/trick_sims/SIM_submarine/models/submarine/include/Submarine.hh
from mf25fb9851ae0aec07f6f6b611d204e49 import *

# S_source.hh
import _maf042a8ac26a39366393033f022b7bed
from maf042a8ac26a39366393033f022b7bed import *

import _top
import top

import _swig_double
import swig_double

import _swig_int
import swig_int

import _swig_ref
import swig_ref

from shortcuts import *

from exception import *

cvar = all_cvars

